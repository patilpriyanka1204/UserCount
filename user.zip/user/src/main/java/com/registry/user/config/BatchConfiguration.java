package com.registry.user.config;

import java.sql.SQLDataException;
import java.sql.SQLException;

import javax.naming.directory.NoSuchAttributeException;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.separator.RecordSeparatorPolicy;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;

import com.registry.user.model.*;
import com.registry.user.repo.DataSourceConfig;


@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private DataSourceConfig dataSourceConfig;

    @Value("${file}")
    private Resource inputResource;

    @Bean
    public Job csvReader() {
        return jobBuilderFactory
                .get("csvReader")
                .incrementer(new RunIdIncrementer())
                .start(step())
                .build();
    }
    
    @Bean
    public Step step() {
        return stepBuilderFactory
                .get("step")
                .<User, User>chunk(3)
                .reader(reader())
                .processor(processor())
                .writer(writer())
                .faultTolerant()
                .skip(NoSuchAttributeException.class)
                .build();
    }
    
    @Bean
    public ItemProcessor<User, User> processor() {
        return new ItemProcessor<User,User>() {
            @Override
            @Nullable
            public User process(User user) throws Exception {
               if((user.getEmail().equals("") || user.getEmail() == null) && (user.getPhone().equals("")|| user.getPhone() == null)){
                    throw new NoSuchAttributeException(); 
               }
               return user;
            }
        };
    }

   
    @Bean
    public FlatFileItemReader<User> reader() {
        FlatFileItemReader<User> itemReader = new FlatFileItemReader<User>();
        itemReader.setLineMapper(lineMapper());
        itemReader.setLinesToSkip(1);
        itemReader.setResource(inputResource);
        return itemReader;
    }
    
    
    @Bean
    public JdbcBatchItemWriter<User> writer() {

        JdbcBatchItemWriter<User> itemWriter = new JdbcBatchItemWriter<User>();

        itemWriter.setDataSource(dataSourceConfig.dataSource());
        itemWriter.setSql("INSERT INTO UserDetails ( EMAIL,PHONE,SOURCE) VALUES ( :email, :phone, :source)");
        itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<User>());
        return itemWriter;
    }


    @Bean
    public LineMapper<User> lineMapper() {
        DefaultLineMapper<User> lineMapper = new DefaultLineMapper<User>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        BeanWrapperFieldSetMapper<User> fieldSetMapper = new BeanWrapperFieldSetMapper<User>();

        lineTokenizer.setNames(new String[]{"email", "phone", "source"});
        lineTokenizer.setIncludedFields(new int[]{0,1,2});
        fieldSetMapper.setTargetType(User.class);
        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);

        return lineMapper;
    }


}

