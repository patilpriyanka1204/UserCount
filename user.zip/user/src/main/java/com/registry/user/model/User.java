package com.registry.user.model;

public class User {
    String email;
    String phone;
    String source;

    public void setEmail(String email) {
        this.email = email;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setSource(String source) {
        this.source = source;
    }
    
    public String getEmail() {
        return email;
    }
    public String getPhone() {
        return phone;
    }
    public String getSource() {
        return source;
    }
    
    public User(){
        
    }
    
}
