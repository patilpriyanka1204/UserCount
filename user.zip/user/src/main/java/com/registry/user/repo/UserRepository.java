package com.registry.user.repo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.registry.user.model.User;

@Repository
public class UserRepository {

    @Autowired
    private DataSourceConfig dataSourceConfig;
    String count = "";
    public String getUser(){
        int c = this.dataSourceConfig.createJdbcTeamplate().queryForObject("Select count(*) from UserDetails;",Integer.class);
        count = Integer.valueOf(c).toString();
        return count;
    }
    
}
