package com.registry.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.registry.user.repo.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public String getUserCount(){
        return userRepository.getUser();
    }
}
