CREATE TABLE IF NOT EXISTS `UserDetails` (
    `id` INTEGER  PRIMARY KEY AUTO_INCREMENT,
     `email` VARCHAR(50),
     `phone` VARCHAR(50),
     `source` VARCHAR(50),
     CONSTRAINT UD_UniqueDetails UNIQUE (email,phone)
);
